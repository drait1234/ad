package com.example.dbprog;

import android.os.Bundle;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener {
    
	EditText txtname,txtadd,txtage,txtid;
	Button sub,search;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtid=(EditText)findViewById(R.id.txt_1);
        txtname=(EditText)findViewById(R.id.txt_2);
        txtage=(EditText)findViewById(R.id.txt_3);
        txtadd=(EditText)findViewById(R.id.txt_4);
        sub=(Button)findViewById(R.id.btn_1);
        sub.setOnClickListener(this);
        search=(Button)findViewById(R.id.btn_2);
        search.setOnClickListener(this);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Toast.makeText(this, "Button clicked", Toast.LENGTH_LONG).show();
		if(v.equals(sub))
		{
			String sid= txtid.getText().toString();
			String sname=txtname.getText().toString();
		    String sage=txtage.getText().toString();
		    String sadd=txtadd.getText().toString();
		    
		    MyDatabase dat= new MyDatabase(this,MyDatabase.DATABASE_NAME,null,1);
		    SQLiteDatabase database= dat.getWritableDatabase();
		    ContentValues cv= new ContentValues();
		    cv.put("id",sid);
		    cv.put("name",sname);
		    cv.put("age",sage);
		    cv.put("addr",sadd);
		    database.insert("employee", null, cv);
		    database.close();
		    Toast.makeText(this,"Data Inserted Successfully",Toast.LENGTH_LONG).show();
		    
		}
		else if(v.equals(search))
		{
			Intent it = new Intent(this,SearchActivity.class);
			startActivity(it);
		}
	}
    
}
