package com.example.dbprog;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends Activity implements OnClickListener {

	EditText ed1;
	Button b1;
	TextView t1;
	@Override
	public void onCreate(Bundle b)
	{
		super.onCreate(b);
		setContentView(R.layout.search);
		ed1=(EditText)findViewById(R.id.txt_5);
		b1=(Button)findViewById(R.id.btn_3);
		t1=(TextView)findViewById(R.id.t33);
		b1.setOnClickListener(this);
	}
	public void onClick(View arg0) {
		// TODO Auto-generated method stub
		String eid=ed1.getText().toString();
		Toast.makeText(this, "Button Clicked", Toast.LENGTH_LONG).show();
		
		MyDatabase dat= new MyDatabase(this,MyDatabase.DATABASE_NAME,null,1);
		SQLiteDatabase database = dat.getReadableDatabase();
		String[] columns = new String[]{"id","name","age","addr"};
		String where="id=?";
		String[] values= new String[]{eid.trim()};
		Cursor cu = database.query(MyDatabase.EMPLOYEE_TABLE,columns,where,values,null,null,null);
		t1.setText("");
		if(cu.moveToNext())
		{
			String id=cu.getString(0);
			String name=cu.getString(1);
			String age=cu.getString(2);
			String addr=cu.getString(3);
			t1.append(id+""+name+""+age+""+addr+"");
		}
		else
		{
			Toast.makeText(this, "Bad Id", Toast.LENGTH_LONG).show();
		}
		
	}

}
