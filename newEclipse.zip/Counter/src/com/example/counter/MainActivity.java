package com.example.counter;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity implements OnClickListener,Runnable{

	Button b1,b2;
	TextView t1;
	Thread th;
	boolean running=false;
	int i=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=(Button)findViewById(R.id.b1);
        b1.setOnClickListener(this);
        b2=(Button)findViewById(R.id.b2);
        b2.setOnClickListener(this);
        t1=(TextView)findViewById(R.id.t1);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }


	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		Toast.makeText(getBaseContext(), "Button clicked", Toast.LENGTH_LONG).show();
		if(v.equals(b1))
		{
			running=true;
			th=new Thread(this);
			th.start();
		}
		else if(v.equals(b2))
		{
			running=false;
		}
	}

	Handler hand=new Handler()
	{
	public void handleMessage(Message m)
	{
	t1.setText(""+m.what);
	}
	};



	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(i<100 && running)
		{
			try{
				Thread.sleep(1000);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			hand.sendEmptyMessage(i);
			i++;
			//t1.setText(""+i);
		}
	}
    
}
