package com.example.calc;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;
import clc.Calculator;

public class Mycalservice extends Service {

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return stub;
	}
	
	Calculator.Stub stub= new Calculator.Stub() {
		
		@Override
		public int sub(int a, int b) throws RemoteException {
			// TODO Auto-generated method stub
			return a-b;
		}
		
		@Override
		public int mul(int a, int b) throws RemoteException {
			// TODO Auto-generated method stub
			return a*b;
		}
		
		@Override
		public int add(int a, int b) throws RemoteException {
			// TODO Auto-generated method stub
			return a+b;
		}
	}; 

	
}
