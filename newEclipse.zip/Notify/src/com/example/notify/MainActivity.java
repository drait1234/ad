package com.example.notify;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.*;

public class MainActivity extends Activity {
TextView lblnumber,lblmessage;
 @Override
 protected void onCreate(Bundle savedInstanceState) {
 super.onCreate(savedInstanceState);
 setContentView(R.layout.activity_main);
 lblnumber=(TextView)findViewById(R.id.num);
 lblmessage=(TextView)findViewById(R.id.conte);
 Bundle b= getIntent().getBundleExtra("data");

 if(b!=null)
 {
 String number=b.getString("number");
 String content=b.getString("content");

 lblnumber.setText(number);
 lblmessage.setText(content);
 }

 }
 
/*public class MainActivity extends Activity {
	
	TextView lblnum,lblconte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lblnum=(TextView)findViewById(R.id.num);
        lblconte=(TextView)findViewById(R.id.conte);
        Bundle b=getIntent().getBundleExtra("data");
        
        if(b!=null)
        {
        	String number=b.getString("number");
        	String content=b.getString("content");
        	
        	lblnum.setText(number);
        	lblconte.setText(content);
        }

    }
*/

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    
}
